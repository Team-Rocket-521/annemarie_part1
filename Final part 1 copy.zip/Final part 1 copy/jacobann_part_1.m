%% Final project part 1
% Prepared by John Bernabei and Brittany Scheid

% One of the oldest paradigms of BCI research is motor planning: predicting
% the movement of a limb using recordings from an ensemble of cells involved
% in motor control (usually in primary motor cortex, often called M1).

% This final project involves predicting finger flexion using intracranial EEG (ECoG) in three human
% subjects. The data and problem framing come from the 4th BCI Competition. For the details of the
% problem, experimental protocol, data, and evaluation, please see the original 4th BCI Competition
% documentation (included as separate document). The remainder of the current document discusses
% other aspects of the project relevant to BE521.



%% Extract dataglove and ECoG data 
% Dataglove should be (samples x 5) array 
% ECoG should be (samples x channels) array

% Split data into a train and test set (use at least 50% for training)

%Training set is 80% of the data or 240,000 samples and testing set is 20%
%of the data or 60,000 samples. 
tr_dg= train_dg{1,1};
train_dg1= tr_dg(1:240000,:);
tr_ecog= train_ecog{1,1};
train_ecog1= tr_ecog(1:240000,:);
te_dg= train_dg{1,1};
test_dg1= te_dg(240001:300000,:);
te_ecog= train_ecog{1,1};
test_ecog1= te_ecog(240001:300000,:);

tr_dg2= train_dg{1,2};
train_dg2= tr_dg2(1:240000,:);
tr_ecog2= train_ecog{2,1};
train_ecog2= tr_ecog2(1:240000,:);
te_dg2= train_dg{1,2};
test_dg2= te_dg2(240001:300000,:);
te_ecog2= train_ecog{2,1};
test_ecog2= te_ecog2(240001:300000,:);


tr_dg3= train_dg{1,3};
train_dg3= tr_dg3(1:240000,:);
tr_ecog3= train_ecog{3,1};
train_ecog3= tr_ecog3(1:240000,:);
te_dg3= train_dg{1,3};
test_dg3= te_dg3(240001:300000,:);
te_ecog3= train_ecog{3,1};
test_ecog3= te_ecog3(240001:300000,:);



%There are 300000 samples in the raw ECoG recording.
%% Get Features
% run getWindowedFeats_release function
cl_dt=filter_data(tr_ecog);
% I used a bandpass filter with 0.5-200Hz as described in the paper. It
% doesnt take long to run either. 
%features=get_features(train_ecog1,1000); testing features
NumberOfWindows=(300000/1000-(.100-.050))/.050
%There will be M=5999 feature windows. 
%%
feature1=getWindowedFeats(train_ecog1,1000, 0.1, 0.05);
feature2=getWindowedFeats(train_ecog2,1000, 0.1, 0.05);
feature3=getWindowedFeats(train_ecog3,1000, 0.1, 0.05);
%%
feature1_test1=getWindowedFeats(test_ecog1,1000, 0.1, 0.05);
feature2_test1=getWindowedFeats(test_ecog2,1000, 0.1, 0.05);
feature3_test1=getWindowedFeats(test_ecog3,1000, 0.1, 0.05);
%% Create R matrix
%R would be [5999x1117] with 62 channels and 6 features and N=3. 
% run create_R_matrix
R=create_R_matrix(testR_features, N_wind); 
mean(mean(R))
%gets right number!
R1=create_R_matrix(feature1,3);
R2=create_R_matrix(feature2,3);
R3=create_R_matrix(feature3,3);
%%
R1_test=create_R_matrix(feature1_test1,3);
R2_test=create_R_matrix(feature2_test1,3);
R3_test=create_R_matrix(feature3_test1,3);
%% Train classifiers (8 points)


% Classifier 1: Get angle predictions using optimal linear decoding. That is, 
% calculate the linear filter (i.e. the weights matrix) as defined by 
% Equation 1 for all 5 finger angles.

Y=[];
Y1=[];
Y(:,1)=downsample(train_dg1(:,1), 50);
Y(:,2)=downsample(train_dg1(:,2), 50);
Y(:,3)=downsample(train_dg1(:,3), 50);
Y(:,4)=downsample(train_dg1(:,4), 50);
Y(:,5)=downsample(train_dg1(:,5), 50);

Y1=Y(1:length(R1),:);
f1=mldivide(R1.'*R1,R1.'*Y1);


y2=[];
Y2=[];
y2(:,1)=downsample(train_dg2(:,1), 50);
y2(:,2)=downsample(train_dg2(:,2), 50);
y2(:,3)=downsample(train_dg2(:,3), 50);
y2(:,4)=downsample(train_dg2(:,4), 50);
y2(:,5)=downsample(train_dg2(:,5), 50);

Y2=y2(1:length(R2),:);

f2=mldivide(R2.'*R2,R2.'*Y2);

y3=[];
Y3=[];
y3(:,1)=downsample(train_dg3(:,1), 50);
y3(:,2)=downsample(train_dg3(:,2), 50);
y3(:,3)=downsample(train_dg3(:,3), 50);
y3(:,4)=downsample(train_dg3(:,4), 50);
y3(:,5)=downsample(train_dg3(:,5), 50);

Y3=y3(1:length(R3),:);

f3=mldivide(R3.'*R3,R3.'*Y3);

%%
% Try at least 1 other type of machine learning algorithm, you may choose
% to loop through the fingers and train a separate classifier for angles 
% corresponding to each finger


%Takes a longgg time to run 
lasso1_p1 = lasso(R1,Y1(:,1));
lasso2_p1 = lasso(R1,Y1(:,2));
lasso3_p1 = lasso(R1,Y1(:,3));
lasso5_p1 = lasso(R1,Y1(:,5));

lasso1_p2 = lasso(R2,Y2(:,1));
lasso2_p2 = lasso(R2,Y2(:,2));
lasso3_p2 = lasso(R2,Y2(:,3));
lasso5_p2 = lasso(R2,Y2(:,5));


lasso1_p3 = lasso(R3,Y3(:,1));
lasso2_p3 = lasso(R3,Y3(:,2));
lasso3_p3 = lasso(R3,Y3(:,3));
lasso5_p3 = lasso(R3,Y3(:,5));
% Try a form of either feature or prediction post-processing to try and
% improve underlying data or predictions.


%% Correlate data to get test accuracy and make figures (2 point)

% Calculate accuracy by correlating predicted and actual angles for each
% finger separately. Hint: You will want to use zohinterp to ensure both 
% vectors are the same length.

Ypred1=R1_test*f1;
Ypred2=R2_test*f2;
Ypred3=R3_test*f3;
%%
up_Ypred1=zoInterp(Ypred1(:,1),50);
up_Ypred12=zoInterp(Ypred1(:,2),50);
up_Ypred13=zoInterp(Ypred1(:,3),50);
up_Ypred15=zoInterp(Ypred1(:,5),50);

up_Ypred21=zoInterp(Ypred2(:,1),50);
up_Ypred22=zoInterp(Ypred2(:,2),50);
up_Ypred23=zoInterp(Ypred2(:,3),50);
up_Ypred25=zoInterp(Ypred2(:,5),50);

up_Ypred31=zoInterp(Ypred3(:,1),50);
up_Ypred32=zoInterp(Ypred3(:,2),50);
up_Ypred33=zoInterp(Ypred3(:,3),50);
up_Ypred35=zoInterp(Ypred3(:,5),50);
%%
p1_c1=corr(up_Ypred1.',test_dg1(1:length(up_Ypred1),1))
p1_c2=corr(up_Ypred12.',test_dg1(1:length(up_Ypred12),2))
p1_c3=corr(up_Ypred13.',test_dg1(1:length(up_Ypred13),3))
p1_c5=corr(up_Ypred15.',test_dg1(1:length(up_Ypred15),5))

p2_c1=corr(up_Ypred21.',test_dg2(1:length(up_Ypred21),1))
p2_c2=corr(up_Ypred22.',test_dg2(1:length(up_Ypred22),2))
p2_c3=corr(up_Ypred23.',test_dg2(1:length(up_Ypred23),3))
p2_c5=corr(up_Ypred25.',test_dg2(1:length(up_Ypred25),5))

p3_c1=corr(up_Ypred31.',test_dg3(1:length(up_Ypred31),1))
p3_c2=corr(up_Ypred32.',test_dg3(1:length(up_Ypred32),2))
p3_c3=corr(up_Ypred33.',test_dg3(1:length(up_Ypred33),3))
p3_c5=corr(up_Ypred35.',test_dg3(1:length(up_Ypred35),5))

%in case latex doesn't show, correlations: (linear)
% %p1_c1 =
% 
%    -0.0413
% 
% 
% p1_c2 =
% 
%     0.0401
% 
% 
% p1_c3 =
% 
%     0.0056
% 
% 
% p1_c5 =
% 
%     0.1791
% 
% 
% p2_c1 =
% 
%     0.0035
% 
% 
% p2_c2 =
% 
%     0.0697
% 
% 
% p2_c3 =
% 
%     0.0038
% 
% 
% p2_c5 =
% 
%    -0.1062
% 
% 
% p3_c1 =
% 
%     0.0446
% 
% 
% p3_c2 =
% 
%    -0.0404
% 
% 
% p3_c3 =
% 
%     0.0323
% 
% 
% p3_c5 =
% 
%    -0.0638
%%

lYpred1=R1_test*lasso1_p1; 
lYpred12=R1_test*lasso2_p1;
lYpred13=R1_test*lasso3_p1;
lYpred15=R1_test*lasso5_p1; 

lYpred21=R2_test*lasso1_p2; 
lYpred22=R2_test*lasso2_p2; 
lYpred23=R2_test*lasso3_p2;
lYpred25=R2_test*lasso5_p2;

lYpred31=R3_test*lasso1_p3; 
lYpred32=R3_test*lasso2_p3; 
lYpred33=R3_test*lasso3_p3; 
lYpred35=R3_test*lasso5_p3;
%%
lup_Ypred1=zoInterp(lYpred1(:,1),50);
lup_Ypred12=zoInterp(lYpred12(:,2),50);
lup_Ypred13=zoInterp(lYpred13(:,3),50);
lup_Ypred15=zoInterp(lYpred15(:,5),50);

lup_Ypred21=zoInterp(lYpred21(:,1),50);
lup_Ypred22=zoInterp(lYpred22(:,2),50);
lup_Ypred23=zoInterp(lYpred23(:,3),50);
lup_Ypred25=zoInterp(lYpred25(:,5),50);

lup_Ypred31=zoInterp(lYpred31(:,1),50);
lup_Ypred32=zoInterp(lYpred32(:,2),50);
lup_Ypred33=zoInterp(lYpred33(:,3),50);
lup_Ypred35=zoInterp(lYpred35(:,5),50);
%%
lp1_c1=corr(lup_Ypred1.',test_dg1(1:length(lup_Ypred1),1))
lp1_c2=corr(lup_Ypred12.',test_dg1(1:length(lup_Ypred12),2))
lp1_c3=corr(lup_Ypred13.',test_dg1(1:length(lup_Ypred13),3))
lp1_c5=corr(lup_Ypred15.',test_dg1(1:length(lup_Ypred15),5))

lp2_c1=corr(lup_Ypred21.',test_dg2(1:length(lup_Ypred21),1))
lp2_c2=corr(lup_Ypred22.',test_dg2(1:length(lup_Ypred22),2))
lp2_c3=corr(lup_Ypred23.',test_dg2(1:length(lup_Ypred23),3))
lp2_c5=corr(lup_Ypred25.',test_dg2(1:length(lup_Ypred25),5))

lp3_c1=corr(lup_Ypred31.',test_dg3(1:length(lup_Ypred31),1))
lp3_c2=corr(lup_Ypred32.',test_dg3(1:length(lup_Ypred32),2))
lp3_c3=corr(lup_Ypred33.',test_dg3(1:length(lup_Ypred33),3))
lp3_c5=corr(lup_Ypred35.',test_dg3(1:length(lup_Ypred35),5))

%In case latex doesnt show correlations, they are: (for lasso)
% lp1_c1 =
% 
%    -0.0369
% 
% 
% lp1_c2 =
% 
%     0.0176
% 
% 
% lp1_c3 =
% 
%     0.0068
% 
% 
% lp1_c5 =
% 
%     0.1905
% 
% 
% lp2_c1 =
% 
%    -0.0336
% 
% 
% lp2_c2 =
% 
%     0.0017
% 
% 
% lp2_c3 =
% 
%     0.0209
% 
% 
% lp2_c5 =
% 
%     0.0047
% 
% 
% lp3_c1 =
% 
%     0.0207
% 
% 
% lp3_c2 =
% 
%     0.0093
% 
% 
% lp3_c3 =
% 
%    -0.0501
% 
% 
% lp3_c5 =
% 
%    -0.0149
