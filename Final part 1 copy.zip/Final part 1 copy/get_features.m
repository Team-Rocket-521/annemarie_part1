function [features] = get_features(clean_data,fs)
    %
    % get_features_release.m
    %
    % Instructions: Write a function to calculate features.
    %               Please create 4 OR MORE different features for each channel.
    %               Some of these features can be of the same type (for example, 
    %               power in different frequency bands, etc) but you should
    %               have at least 2 different types of features as well
    %               (Such as frequency dependent, signal morphology, etc.)
    %               Feel free to use features you have seen before in this
    %               class, features that have been used in the literature
    %               for similar problems, or design your own!
    %
    % Input:    clean_data: (samples x channels)
    %           fs:         sampling frequency
    %
    % Output:   features:   (1 x (channels*features))
    % 
%% Your code here (8 points)
%feature 1, zero mean
% zero_feat=[];
% for i=1:size(clean_data,2)
% ZX = sum(diff(sign(clean_data(:,i)-mean(clean_data(:,i))))<0)+ sum(diff(sign(clean_data(:,i)-mean(clean_data(:,i))))>0);
% zero_feat=[zero_feat,ZX];
% end
% %feature 1, spectrogram
% spec=[];
% for i=1:size(clean_data,2)
%     s=mean(mean(spectrogram(clean_data(:,i))));
%     spec=[spec,s];
% end

%feature 3, average power
power1=[];
for i=1:size(clean_data,2)
p1=bandpower(clean_data(:,i),fs,[20 25]);
power1=[power1,p1];
end
%feature 2, mean voltage
voltage=[];
for i=1:size(clean_data,2)
v=mean(clean_data(:,i));
voltage=[voltage,v];
end

%feature 3, average power
power=[];
for i=1:size(clean_data,2)
p=bandpower(clean_data(:,i),fs,[5 15]);
power=[power,p];
end



line=[];
for i=1:size(clean_data,2)
    s=sum(abs(diff(clean_data(:,i))));
    line=[line,s];
end

features=[power1,voltage,power,line];
end

