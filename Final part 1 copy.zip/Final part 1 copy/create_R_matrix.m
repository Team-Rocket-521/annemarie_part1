function [R]=create_R_matrix(features, N_wind)
    %
    % get_features_release.m
    %
    % Instructions: Write a function to calculate R matrix.             
    %
    % Input:    features:   (samples x (channels*features))
    %           N_wind:     Number of windows to use
    %
    % Output:   R:          (samples x (N_wind*channels*features))
    % 
%% Your code here (5 points)

%3.1 
%The dimensions of R are (samples x (N_wind*channels*features))
%where M=5999, so [5999x(3*62*6)] or 1116+1=1117, so [5999x1117]
R=zeros(length(features),size(features,2)*N_wind+1);
R(:,1)=1;
mat=[];
mat2=[];
num_rows=N_wind-1;

appended=zeros((length(features)+num_rows),size(features,2));

for i=1:num_rows
    appended(i,:)=features(i,:);
end

for i=num_rows+1:length(appended)
    appended(i,:)=features(i-num_rows,:);
end

for i=1:length(appended)-num_rows
    for j=0:num_rows
        mat=[mat, appended(i+j,:)];
    end
    mat2=[mat2; mat];
    mat=[];
end

for i=1:size(mat2,2)
    R(:,i+1)=mat2(:,i);
end

end
